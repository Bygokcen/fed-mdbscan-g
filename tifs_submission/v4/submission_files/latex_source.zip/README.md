# English manuscript sources

Compile in manuscript/ with a standard LaTeX installation:

    pdflatex -interaction=nonstopmode -halt-on-error main.tex
    bibtex main
    pdflatex -interaction=nonstopmode -halt-on-error main.tex
    pdflatex -interaction=nonstopmode -halt-on-error main.tex
    pdflatex -interaction=nonstopmode -halt-on-error supplement.tex
    pdflatex -interaction=nonstopmode -halt-on-error supplement.tex

The supplied tables and figures are generated from the separate reproducibility artifact. No raw training data is required to compile the manuscript. IEEEtran files retain their original notices. The Turkish working translation is not part of the submission sources.
