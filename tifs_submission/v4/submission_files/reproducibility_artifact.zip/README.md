# Reproducibility artifact for V4

This is the summary-level evidence accompanying "Benign Exclusion and Consensus-Test Limits in Heterogeneous Federated Learning".

Use Python 3.10 or later with matplotlib (the existing project environment already provides them). From this directory:

    python analysis/build_tables.py --root .

This regenerates 14 English LaTeX tables, two figures, analysis/derived_values.json and paired benign-utility differences. Generated tables are under manuscript/generated/ and figures under manuscript/figures/. The separate latex_source.zip supplies the full manuscript sources. No network, GPU, retraining or raw archive is needed for this summary-level calculation.

The 2,130 planned units retain 2,125 valid units and five failures. These are retrospective descriptive checks, not independent replications or significance tests. The 72 recorded matrices yield 36 distinct attacked matrices; duplicate gate rows are not counted as additional matrices.

Input CSV/JSON files preserve their original hashes. SHA256SUMS.json identifies the contents of this package; a digest establishes content identity, not preregistration. Existing provenance files retain historical source paths. Those paths are references to the local research archive and are not expected to exist in a clone.

Limits: exported tables permit checking arithmetic and consistency. Repeating the historical per-round identity audit, recapturing checkpoints, or rerunning training requires the separately held raw archive and frozen environment. This ZIP does not include raw training artifacts, dataset files, authors' third-party implementation archives, or the full simulation environment. Baselines remain local implementations with the fidelity limits stated in the paper. The pipeline verifies available copied-report hashes and condition metadata; it does not recreate the missing raw audit from summaries.
